from django.apps import AppConfig


class PredictionConfig(AppConfig):
    name = 'Prediction'
